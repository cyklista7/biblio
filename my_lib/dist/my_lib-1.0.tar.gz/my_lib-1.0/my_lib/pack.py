def pack(number):
    return number + 1